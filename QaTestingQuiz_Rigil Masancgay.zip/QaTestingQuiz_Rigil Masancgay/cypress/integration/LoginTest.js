const { cyan } = require("color-name")

describe('Login Test', () => {
    it('correct username/password', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=user-name]').type('standard_user')
        cy.get('[id^=password]').type('secret_sauce')
        cy.get('[id^=login-button]').click()
        cy.get('div').contains('Products')
    })

    it('correct username/incorrect password', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=user-name]').type('standard_user')
        cy.get('[id^=password]').type('secret_saucess')
        cy.get('[id^=login-button]').click()
        cy.get('h3').contains('Epic sadface: Username and password do not match any user in this service')
    })

    it('incorrect username/incorrect password', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=user-name]').type('standard_userss')
        cy.get('[id^=password]').type('secret_sauces')
        cy.get('[id^=login-button]').click()
        cy.get('h3').contains('Epic sadface: Username and password do not match any user in this service')
    })

    it('click Login button without username/password', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=login-button]').click()
        cy.get('h3').contains('Epic sadface: Username is required')
    })

    it('blank username/ with password', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=password]').type('secret_sauces')
        cy.get('[id^=login-button]').click()
        cy.get('h3').contains('Epic sadface: Username is required')
    })

    it('with username/ blank password', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=user-name]').type('standard_user')
        cy.get('[id^=login-button]').click()
        cy.get('h3').contains('Epic sadface: Password is required')
    })

    it('locked out user', () => {
        cy.visit('https://www.saucedemo.com/')
        cy.get('[id^=user-name]').type('locked_out_user')
        cy.get('[id^=password]').type('secret_sauce')
        cy.get('[id^=login-button]').click()
        cy.get('h3').contains('Epic sadface: Sorry, this user has been locked out.')
    })
})